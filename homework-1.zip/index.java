void setup(){
  size(600, 400);

  background(0,0,0);
  //R,G,B
}

void draw(){
 int y;
 int x;
 y = 0;
 x = 100;
 while (y <= 30)
 {
   fill(150,150,150);
    rect(30,x,170,5);
    rect(370,x,170,5);
    rect(200,x+120,170,5);
    x = x + 10;
    y = y + 10;

 }
 
  
}